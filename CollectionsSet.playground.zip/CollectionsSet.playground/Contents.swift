import UIKit

var hayvanlar = Set<String>()

//Veri ekleme
hayvanlar.insert("Kedi")
hayvanlar.insert("Köpek")
hayvanlar.insert("Aslan")
print(hayvanlar)

hayvanlar.insert("Aslan") //ekran çıktısında eklemedi. çünkü bir tane aslan yazdırdı, tek bir kere yazdırıyor.
print(hayvanlar)

hayvanlar.insert("Çin Aslanı") //her ne kadar az önce aslan eklemese bile bu aslan değil çin aslanı ve aynısından başka yok diye ekledi.
print(hayvanlar)


//döngülerle de çalışabiliriz.

for hayvan in hayvanlar {
    print("Sonuç :\(hayvan)")
}
for (indeks,hayvan) in hayvanlar.enumerated(){ // indeks numaralarıyla ekrana yazdırmak için
    print("\(indeks). -> \(hayvan)")
}
        
print("Boyut : \(hayvanlar.count)")  //içinde kaç veri bakmak için
print("Boş mu :\(hayvanlar.isEmpty)") //içinde veri var mı yok mu bakmak için

//veri silmek için;
hayvanlar.remove("Köpek")
print(hayvanlar)



//setin içindeki verilerin tamamını silmek için
hayvanlar.removeAll()
print(hayvanlar)
